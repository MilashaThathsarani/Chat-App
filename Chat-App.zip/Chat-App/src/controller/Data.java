package controller;

public class Data {
    public static String username = "Unknown";
}
