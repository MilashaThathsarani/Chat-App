package util;

public class ConnectionUtil {
    public static String host = "localhost";
    public static int port = 5000;
}
